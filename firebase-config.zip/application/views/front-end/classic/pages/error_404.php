<section class='error_404'>
    
<h1 data-shadow='oops!'>oops!</h1>
<div class='col-12'>
<img src="<?=THEME_ASSETS_URL.'temp/404.jpg'?>" class='w-100'/>
</div>
</section>