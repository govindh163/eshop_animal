<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-02 16:54:35 --> 404 Page Not Found: Cgi_sys/defaultwebpage.cgi
ERROR - 2022-03-02 16:54:42 --> Severity: error --> Exception: Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\eshop_web\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-03-02 16:55:02 --> Severity: error --> Exception: Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\eshop_web\system\database\drivers\mysqli\mysqli_driver.php 203
